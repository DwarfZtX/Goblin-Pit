# Multiplayer FPS Tutorial

This repo is the final product of my Blender/Godot video where I walk through making this project from scratch.

Check out the tutorial [here](https://youtu.be/n8D3vEx7NAE)!
